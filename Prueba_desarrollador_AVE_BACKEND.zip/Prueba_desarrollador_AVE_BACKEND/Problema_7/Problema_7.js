const taskForm = document.getElementById('taskForm');
const taskTable = document.getElementById('taskTable');
const clearButton = document.getElementById('clearButton');

taskForm.addEventListener('submit', function (event) {
    event.preventDefault();

    const taskName = document.getElementById('taskName').value;
    const taskDate = document.getElementById('taskDate').value;
    const taskPriority = document.getElementById('taskPriority').value;
    const taskDescription = document.getElementById('taskDescription').value;

    const newRow = taskTable.insertRow(-1);
    newRow.innerHTML = `
    <td>${taskName}</td>
    <td>${taskDate}</td>
    <td>${taskPriority}</td>
    <td>${taskDescription}</td>
    <td>
      <button class="editButton">Edit</button>
      <button class="deleteButton">Delete</button>
    </td>
  `;

    clearForm();
});

function clearForm() {
    taskForm.reset();
}

clearButton.addEventListener('click', clearForm);

taskTable.addEventListener('click', function (event) {
    const target = event.target;
    if (target.classList.contains('deleteButton')) {
        const row = target.parentNode.parentNode;
        taskTable.deleteRow(row.rowIndex);
    } else if (target.classList.contains('editButton')) {
        const row = target.parentNode.parentNode;
        const cells = row.querySelectorAll('td');
        const taskName = cells[0].innerText;
        const taskDate = cells[1].innerText;
        const taskPriority = cells[2].innerText;
        const taskDescription = cells[3].innerText;

        document.getElementById('taskName').value = taskName;
        document.getElementById('taskDate').value = taskDate;
        document.getElementById('taskPriority').value = taskPriority;
        document.getElementById('taskDescription').value = taskDescription;
    }
});
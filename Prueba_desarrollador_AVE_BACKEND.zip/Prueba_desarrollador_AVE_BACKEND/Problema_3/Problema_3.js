function validarPassword(password) {
    if (password.length < 16) {
      return false;
    }
  
    let letrasConsecutivas = false;
    let numerosConsecutivos = false;
    let contadorCaracteres = 0;
    let caracteresEspeciales = '!@#$%^&*-_+=?';
    let prevChar = '';
  
    let contadorNumeros = 0;
    let hasLowercase = false;
    let hasUppercase = false;
  
    for (let i = 0; i < password.length; i++) {
      const currentChar = password[i];
  
      if (currentChar === ' ' || currentChar === '0') {
        return false;
      }
  
      if (currentChar >= 'a' && currentChar <= 'z') {
        hasLowercase = true;
      } else if (currentChar >= 'A' && currentChar <= 'Z') {
        hasUppercase = true;
      } else if (currentChar >= '0' && currentChar <= '9') {
        contadorNumeros++;
        if (currentChar === prevChar) {
          numerosConsecutivos = true;
        }
      } else if (caracteresEspeciales.includes(currentChar)) {
        contadorCaracteres++;
        if (currentChar === prevChar || (i > 0 && password[i - 1] === prevChar)) {
          return false;
        }
      } else {
        return false; // Caracter no permitido
      }
  
      if (currentChar === prevChar) {
        letrasConsecutivas = true;
      }
  
      prevChar = currentChar;
    }
  
    return (
      contadorNumeros >= 4 &&
      hasLowercase &&
      hasUppercase &&
      !letrasConsecutivas &&
      !numerosConsecutivos &&
      contadorCaracteres >= 2
    );
  }
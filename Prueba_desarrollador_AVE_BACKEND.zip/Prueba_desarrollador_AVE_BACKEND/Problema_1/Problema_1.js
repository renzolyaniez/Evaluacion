function multiplicarSinMultiplicacion(numero1, numero2) {
    if (numero1 === 0 || numero2 === 0) {
      return 0;
    }
  
    let resultado = 0;
  
    for (let i = 0; i < numero2; i++) {
      resultado = resultado + numero1;
    }
  
  
    return (numero1+" * "+numero2+" = "+resultado);
  }
  
  // Ejemplos de uso
  console.log(multiplicarSinMultiplicacion(5, 5)); 
  console.log(multiplicarSinMultiplicacion(6, 7)); 
  console.log(multiplicarSinMultiplicacion(-5, 10)); 
function analizarArrayNumeros(arrayNumeros) {
    if (!Array.isArray(arrayNumeros)) {
        console.error('La entrada no es un array
        return null;
    }

    if (arrayNumeros.length === 0) {
        console.error('El array está vacío');
        return null;
    }

    // Cantidad de elementos del arreglo
    const count = arrayNumeros.length;

    // Porcentaje de números pares e impares
    let contadorPar = 0;
    let contadorImpar = 0;
    arrayNumeros.forEach((number) => {
        if (number % 2 === 0) {
            contadorPar++;
        } else {
            contadorImpar++;
        }
    });
    const porcentajePares = (contadorPar / count) * 100;
    const porcentajeImpares = (contadorImpar / count) * 100;

    // Porcentaje de números mayores a 1000
    const contadorMayorAMil = arrayNumeros.filter((number) => number > 1000).length;
    const porcentajeMayorAMil = (contadorMayorAMil / count) * 100;

    // Mayor y menor valor
    const numeroMaximo = Math.max(...arrayNumeros);
    const numeroMimino = Math.min(...arrayNumeros);

    // Porcentaje del número mínimo
    const porcentajeNumMinimo = (numeroMimino / numeroMaximo) * 100;

    // Porcentaje del promedio de todos los números
    const sum = arrayNumeros.reduce((acc, cur) => acc + cur, 0);
    const average = sum / count;
    const porcentajePromedio = (average / numeroMaximo) * 100;

    return {
        count,
        porcentajePares,
        porcentajeImpares,
        porcentajeMayorAMil,
        numeroMaximo,
        numeroMimino,
        porcentajeNumMinimo,
        porcentajePromedio,
    };
}


const numbers = [15, 21, 1005, 3000, 500, 1500];
const result = analizarArrayNumeros(numbers);
console.log(result);
async function searchPokemon() {
    const searchInput = document.getElementById('searchInput');
    const pokemonDataDiv = document.getElementById('pokemonData');
  
    const searchTerm = searchInput.value.trim().toLowerCase();
    if (searchTerm === '') {
      pokemonDataDiv.innerHTML = '<p>Please enter a Pokémon name or number.</p>';
      return;
    }
  
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${searchTerm}`);
      if (!response.ok) {
        pokemonDataDiv.innerHTML = `<p>Pokémon not found for '${searchTerm}'.</p>`;
        return;
      }
  
      const data = await response.json();
      const { name, id, types, weight, height, sprites } = data;
  
      const pokemonData = `
        <h2>${name}</h2>
        <p>Number: ${id}</p>
        <p>Type: ${types.map(type => type.type.name).join(', ')}</p>
        <p>Weight: ${weight} kg</p>
        <p>Height: ${height} dm</p>
        <img src="${sprites.front_default}" alt="${name} sprite">
      `;
  
      pokemonDataDiv.innerHTML = pokemonData;
    } catch (error) {
      pokemonDataDiv.innerHTML = `<p>Error fetching Pokémon data: ${error.message}</p>`;
    }
  }
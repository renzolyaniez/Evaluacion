let n1 = prompt("Ingrese un numero");
let n2 = prompt("Ingrese otro numero");

n1 = parseInt(n1);
n2 = parseInt(n2);
let resultado = n1 + n2;

console.log("resultado = "+resultado);
//Suma total de pokemones por tipo:
async function getTotalPokemonsByType(type) {
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/type/${type}`);
      const data = await response.json();
      return data.pokemon.length;
    } catch (error) {
      console.error(error);
      return 0;
    }
  }

  //Dado 2 tipos de pokémon, retornar todos los pokemones que cumplen con esos 2 tipos:
  async function getPokemonsByTypes(type1, type2) {
    try {
      const response1 = await fetch(`https://pokeapi.co/api/v2/type/${type1}`);
      const response2 = await fetch(`https://pokeapi.co/api/v2/type/${type2}`);
      const data1 = await response1.json();
      const data2 = await response2.json();
      const pokemonsTipo1 = data1.pokemon.map((item) => item.pokemon.name);
      const pokemonsTipo2 = data2.pokemon.map((item) => item.pokemon.name);
      return pokemonsTipo1.filter((pokemon) => pokemonsTipo2.includes(pokemon));
    } catch (error) {
      console.error(error);
      return [];
    }
  }

  //Dado el nombre de un pokémon, retornar el número del mismo:
  async function getPokemonNumberByName(nombre) {
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${nombre}`);
      const data = await response.json();
      return data.id;
    } catch (error) {
      console.error(error);
      return null;
    }
  }

  //Dado el número de un pokémon, retornar un objeto con sus 6 stats base:
  async function getPokemonStatsByNumber(numero) {
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${numero}`);
      const data = await response.json();
      const stats = {};
      data.stats.forEach((stat) => {
        stats[stat.stat.nombre] = stat.base_stat;
      });
      return stats;
    } catch (error) {
      console.error(error);
      return null;
    }
  }

  //Realizar una función que reciba un arreglo de números (Ids de pokémon) y un ordenador y retorne los pokémon en un arreglo con su nombre, tipo y peso ordenados según se indique por la función por uno de estos 3 indicadores: javascript
  async function sortPokemonsByIds(ids, sortBy) {
    try {
      const promises = ids.map(async (id) => {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
        const data = await response.json();
        return {
          nombre: data.nombre,
          tipo: data.types.map((type) => type.type.name),
          peso: data.peso,
        };
      });
  
      const pokemons = await Promise.all(promises);
  
      switch (sortBy) {
        case 'nombre':
          pokemons.sort((a, b) => a.nombre.localeCompare(b.nombre));
          break;
        case 'tipo':
          pokemons.sort((a, b) => a.tipo.join(', ').localeCompare(b.tipo.join(', ')));
          break;
        case 'peso':
          pokemons.sort((a, b) => a.peso - b.peso);
          break;
        default:
          console.error('Parametro inválido.');
          return [];
      }
  
      return pokemons;
    } catch (error) {
      console.error(error);
      return [];
    }
  }

  //Recibir un número y un tipo (de pokémon) y retornar un true o false si el pokémon de ese número posee este tipo:
  async function isPokemonOfType(number, type) {
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${number}`);
      const data = await response.json();
      return data.types.some((t) => t.type.name === type);
    } catch (error) {
      console.error(error);
      return false;
    }
  }